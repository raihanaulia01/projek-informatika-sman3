const companyLogosWrapper = document.getElementById("company-logos");
console.log(companyLogosWrapper);
const populateLogos = () => {
  const url = "img/company-logos/Group-";
  for (let i = 0; i < 18; i++) {
    const img = document.createElement("img");
    img.src = url + i + ".svg";
    img.className="company-logo";
    companyLogosWrapper.appendChild(img);
  }
}
populateLogos();
